# Bugfish Framework
See www.bugfish.eu for informations (Forum or Wiki) 
Or in Readme Files inside Folders.  

This is the Bugfish Framework, for easier Coding.  It Contains different Classes and Functions, see below for instructions and library. Languages are Javascript / Jquery / PHP / Html / CSS Classes should be all injection safe, as requests are made with sql-param-binds. But i do never guarantee! 

You can find the documentation at www.bugfish.eu, besides  that there is a documentation inside the docs folder of this repository and at https://bugfishtm.github.io/bugfish-framework !


Peace out!  
Bugfish